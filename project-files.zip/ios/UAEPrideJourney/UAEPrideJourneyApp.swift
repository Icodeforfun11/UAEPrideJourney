import SwiftUI

@main
struct UAEPrideJourneyApp: App {
    var body: some Scene {
        WindowGroup {
            JourneyWebView()
                .ignoresSafeArea()
                .background(Color(red: 0.965, green: 0.937, blue: 0.875))
                .statusBarHidden(false)
                .preferredColorScheme(.light)
                // Event mode: keep the shared school iPad awake.
                .onAppear { UIApplication.shared.isIdleTimerDisabled = true }
        }
    }
}
